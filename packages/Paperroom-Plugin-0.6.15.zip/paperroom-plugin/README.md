# Paperroom 0.6.15

On macOS, double-click [Try-Paperroom.command](Try-Paperroom.command) in this extracted folder to try the three-level outline and section review on a sample paper.

Claude Code users can double-click [Enable-Claude-Updates.command](Enable-Claude-Updates.command) to upgrade and turn on automatic updates from the main branch, where releases are published, then reopen their Claude Code session.

To use Paperroom in Claude Code or Codex, double-click [Install-Paperroom.command](Install-Paperroom.command), or run `python3 install.py` here (Python 3.9 or later). Reload plugins and ask, in your paper's folder, "Use Paperroom to rewrite my introduction." Codex asks you to approve Paperroom's hooks once in `/hooks`.

Claude desktop Chat uses the separate Paperroom.mcpb. Verify an exported writing log with `python3 scripts/verify_timestamps.py record.json`.

Read the [writing guide](docs/writing-guide.md) for each step, references, polish and figures. Your AI reads its own [instructions](plugins/paperroom/runtime/README-workflow.md) by calling `get_usage()`.

## 中文

解压完整目录后，在 macOS 双击 [Try-Paperroom.command](Try-Paperroom.command)，就能在浏览器里体验三级大纲和整节审阅。示例使用本包内的虚构实验，单独运行即可。

Claude Code 用户可双击 [Enable-Claude-Updates.command](Enable-Claude-Updates.command)，将已有插件升级并开启 GitHub main 分支（正式发布版）的自动更新。重新打开本地 Claude Code 会话即可加载新版。

要在 Claude Code 或 Codex 的原聊天里使用，请双击 [Install-Paperroom.command](Install-Paperroom.command)，或在解压目录运行 `python3 install.py`。需要 Python 3.9 或以上版本。重新载入插件，在论文项目里说“用 Paperroom 帮我重写引言”。

Claude 桌面版 Chat 请安装另行提供的 Paperroom.mcpb。每一步怎么做、怎样请 AI 给参考或润色、图表放在哪里，见[写作指导](docs/writing-guide.zh-CN.md)。AI 调用 `get_usage()` 会读到写给它的[操作说明](plugins/paperroom/runtime/README-workflow.md)。

核验写作间导出的时间戳文件可运行 `python3 scripts/verify_timestamps.py record.json`。可用 `--ca-file trusted-ca.pem` 指定核验者信任的 CA 证书。

[项目主页](https://github.com/jiayangniu/Paperroom) · [许可](LICENSE)
