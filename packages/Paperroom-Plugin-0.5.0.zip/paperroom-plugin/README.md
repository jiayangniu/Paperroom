# Paperroom 0.5.0

解压完整目录后，在 macOS 双击 [Try-Paperroom.command](Try-Paperroom.command)，就能在浏览器里体验三级大纲和整节审阅。示例使用本包内的虚构实验，单独运行即可。

Claude Code 用户可双击 [Enable-Claude-Updates.command](Enable-Claude-Updates.command)，将已有插件升级并开启 GitHub 第二版分支的自动更新。重新打开本地 Claude Code 会话即可加载新版。

要在 Claude Code 或 Codex 的原聊天里使用，请双击 [Install-Paperroom.command](Install-Paperroom.command)，或在解压目录运行 `python3 install.py`。需要 Python 3.9 或以上版本。重新载入插件，在论文项目里说“用 Paperroom 帮我重写引言”。

Claude 桌面版 Chat 请安装另行提供的 Paperroom.mcpb。

核验写作间导出的时间戳文件可运行 `python3 scripts/verify_timestamps.py record.json`。可用 `--ca-file trusted-ca.pem` 指定核验者信任的 CA 证书。

[项目主页](https://github.com/jiayangniu/Paperroom) · [许可](LICENSE)
